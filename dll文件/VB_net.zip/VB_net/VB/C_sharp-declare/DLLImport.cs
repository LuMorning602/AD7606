﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

public delegate bool CallBack(byte bIndex, UInt32 dwUSBStatus);

struct ADC_CONFIG
 {
	/*
	  byADCOptions:

	  bit5     for AD706 period unit            0- US, 1- MS
	  bit4     for AD7606 range:                1- in +10V ~ -10V,    0- in +5v ~ -5v
	  bit0~2   for AD7606 OS;
	*/
	public byte  byADCOptions;
	/*
	  byTrigOptions:

	  bit7     for AD7606 samping:                1- in sampling,    0- stop
	  bit4     for AD706 trig vol selection       0- large or equal, 1- small or equal
	  bit2~3   for AD7606 IO selection:           00- falling, 01- Raising , 10- raising and falling
	  bit0~1   for AD7606 trig mode;              00- GPIO trig, 01- period trig, 10- GPIO + period，11- trigVol + period
	*/

	public byte  byTrigOptions;
	public UInt16  wReserved1;
	public byte  byMainCh;
	public byte  byUnused;
	public UInt16  wReserved2;
  /* wPeriod: Timer trig period, unit byADCOptions bit 5~6 */
	public UInt16  wPeriod;
	public UInt16  wTrigVol; //unit mv
 /* dwTrigCnt: current trig counter */
	public UInt32 dwCycleCnt;
  /* dwMaxCnt: Max Enabled trig number , trig will exit if dwTrigCnt is equal to dwMaxCnt */
	public UInt32 dwMaxCycles;
 }

namespace USB2DaqsA
{
    class DLLImport
    {
        /*--------------------------------DLL function import---------------------------------*/


        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_SetUSBNotify(bool bLoged, CallBack pUSB_CallBack);       

        [DllImport("USB2DaqsA.dll")]
        public static extern byte M3F20xm_OpenDevice();
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_Verify(byte byIndex);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_CloseDevice(byte bIndex);
        [DllImport("USB2DaqsA.dll")]
        public static extern byte M3F20xm_OpenDeviceByNumber(StringBuilder pSerial);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_CloseDeviceByNumber(StringBuilder pSerial);
        [DllImport("USB2DaqsA.dll")]
        public static extern byte M3F20xm_GetSerialNo(byte bIndex, StringBuilder pSerial);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_GetVersion(byte bIndex, byte bType, StringBuilder pVersion);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_DFUMode(byte byIndex);

       

        /*here are ADC functions*/
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCGetConfig(byte bIndex, ref ADC_CONFIG pCfg);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCSetConfig(byte bIndex, ref ADC_CONFIG pCfg);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCRead(byte bIndex, UInt16[] byReadData);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCStart(byte bIndex);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCStop(byte bIndex);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCReset(byte bIndex);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ADCStandBy(byte bIndex);  
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_DFUPinGet(byte byIndex, ref byte plevel);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_DFUPinSet(byte byIndex,byte level);
           
        /*here are the FIFO function*/
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_InitFIFO(byte byIndex);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_ReadFIFO(byte byIndex, byte[] lpBuffer, UInt32 dwBuffSize, ref UInt32 pdwRealSize);
        [DllImport("USB2DaqsA.dll")]
        public static extern bool M3F20xm_GetFIFOLeft(byte byIndex, ref UInt32 pdwBuffsize);
        /*--------------------------------End---------------------------------*/
    }
}
