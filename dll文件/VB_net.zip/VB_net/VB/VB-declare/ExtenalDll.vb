﻿Module userdefine
    Public WM_USB_STATUS = &H400 + 100
    Public WM_TRIG_STATUS = &H400 + 101
    Public mHandle As Integer
    Public sFormTitle As String
    Public Declare Function PostMessage Lib "user32" Alias "PostMessageA" (ByVal hwnd As Int32, ByVal wMsg As Int32, ByVal wParam As Int32, ByVal lParam As Int32) As Long
    Private Declare Auto Function FindWindow Lib "user32" (ByVal lpClassName As String, ByVal lpWindowName As String) As Integer
    Public Delegate Function CallBack(ByVal byIndex As Byte, ByVal dwStatus As UInteger) As Boolean

    Public Function USB_Event(ByVal byIndex As Byte, ByVal dwUSBStatus As UInteger) As Boolean
        mHandle = FindWindow(vbNullString, sFormTitle)
        PostMessage(mHandle, WM_USB_STATUS, byIndex, dwUSBStatus)
        Return True
    End Function
End Module

Public Structure ADCCONFIG
Dim byADCOptions As Byte
Dim byTrigOptions as Byte
Dim wReserved1 as short
Dim byMainCh As Byte
    Dim byUnused As Byte
    Dim wReserved2 As Short
    Dim wPeriod As UInteger
Dim wTrigVol As short
Dim dwCycleCnt As UInteger
Dim dwMaxCycles As UInteger
End Structure

Module ExtenalDll

#If X64 Then

    Public Declare Function M3F20xm_SetUSBNotify Lib "USB2DaqsA.dll" (ByVal bLoged As Boolean, ByVal pUSB_CallBack As CallBack) As Boolean

    Public Declare Function M3F20xm_OpenDevice Lib "USB2DaqsA.dll" () As Byte
    Public Declare Function M3F20xm_OpenDeviceByNumber Lib "USB2DaqsA.dll" (ByVal pSerialString As String) As Byte
    Public Declare Function M3F20xm_CloseDevice Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_CloseDeviceByNumber Lib "USB2DaqsA.dll" (ByVal pSerialString As String) As Boolean
    Public Declare Function M3F20xm_GetVersion Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByVal byType As Byte, ByVal lpBuffer As String) As Boolean
    Public Declare Function M3F20xm_GetSerialNo Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByVal lpBuff As String) As Byte
    Public Declare Function M3F20xm_Verify Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean

    Public Declare Function M3F20xm_InitFIFO Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ReadFIFO Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByVal lpReadBuffer() As Byte, ByVal dwBuffSize As UInteger, ByRef pdwRealSize As UInteger) As Boolean
    Public Declare Function M3F20xm_GetFIFOLeft Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByRef pdwBuffsize As UInteger) As Boolean

    Public Declare Function M3F20xm_ADCGetConfig Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByRef pcfg As ADCCONFIG) As Boolean
    Public Declare Function M3F20xm_ADCSetConfig Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByVal pcfg As ADCCONFIG) As Boolean
    Public Declare Function M3F20xm_ADCRead Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByVal lpReadBuffer() As Short) As Boolean
    Public Declare Function M3F20xm_ADCStart Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ADCStop Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ADCReset Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ADCStandBy Lib "USB2DaqsA.dll" (ByVal byIndex As Byte) As Boolean

    Public Declare Function M3F20xm_DFUPinGet Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByRef pbylevel As Byte) As Boolean
    Public Declare Function M3F20xm_DFUPinSet Lib "USB2DaqsA.dll" (ByVal byIndex As Byte, ByVal byLevel As Byte) As Boolean

#Else
    Public Declare Function M3F20xm_SetUSBNotify Lib "USB2DaqsA.dll" Alias "_M3F20xm_SetUSBNotify@8" (ByVal bLoged As Boolean, ByVal pUSB_CallBack As CallBack) As Boolean

    Public Declare Function M3F20xm_OpenDevice Lib "USB2DaqsA.dll" Alias "_M3F20xm_OpenDevice@0" () As Byte
    Public Declare Function M3F20xm_OpenDeviceByNumber Lib "USB2DaqsA.dll" Alias "_M3F20xm_OpenDeviceByNumber@4" (ByVal pSerialString As String) As Byte
    Public Declare Function M3F20xm_CloseDevice Lib "USB2DaqsA.dll" Alias "_M3F20xm_CloseDevice@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_CloseDeviceByNumber Lib "USB2DaqsA.dll" Alias "_M3F20xm_CloseDeviceByNumber@4" (ByVal pSerialString As String) As Boolean
    Public Declare Function M3F20xm_GetVersion Lib "USB2DaqsA.dll" Alias "_M3F20xm_GetVersion@12" (ByVal byIndex As Byte, ByVal byType As Byte, ByVal lpBuffer As String) As Boolean
    Public Declare Function M3F20xm_GetSerialNo Lib "USB2DaqsA.dll" Alias "_M3F20xm_GetSerialNo@8" (ByVal byIndex As Byte, ByVal lpBuff As String) As Byte
    Public Declare Function M3F20xm_Verify Lib "USB2DaqsA.dll" Alias "_M3F20xm_Verify@4" (ByVal byIndex As Byte) As Boolean

    Public Declare Function M3F20xm_InitFIFO Lib "USB2DaqsA.dll" Alias "_M3F20xm_InitFIFO@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ReadFIFO Lib "USB2DaqsA.dll" Alias "_M3F20xm_ReadFIFO@16" (ByVal byIndex As Byte, ByVal lpReadBuffer() As Byte, ByVal dwBuffSize As UInteger, ByRef pdwRealSize As UInteger) As Boolean
    Public Declare Function M3F20xm_GetFIFOLeft Lib "USB2DaqsA.dll" Alias "_M3F20xm_GetFIFOLeft@8" (ByVal byIndex As Byte, ByRef pdwBuffsize As UInteger) As Boolean

    Public Declare Function M3F20xm_ADCGetConfig Lib "USB2DaqsA.dll" Alias "_M3F20xm_ADCGetConfig@8" (ByVal byIndex As Byte, ByRef pcfg As ADCCONFIG) As Boolean
    Public Declare Function M3F20xm_ADCSetConfig Lib "USB2DaqsA.dll" Alias "_M3F20xm_ADCSetConfig@8" (ByVal byIndex As Byte, ByRef pcfg As ADCCONFIG) As Boolean
    Public Declare Function M3F20xm_ADCRead Lib "USB2DaqsA.dll" Alias "_M3F20xm_ADCRead@8" (ByVal byIndex As Byte, ByVal lpReadBuffer() As Short) As Boolean
    Public Declare Function M3F20xm_ADCStart Lib "USB2DaqsA.dll" Alias "_M3F20xm_ADCStart@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ADCStop Lib "USB2DaqsA.dll" Alias "_M3F20xm_ADCStop@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ADCReset Lib "USB2DaqsA.dll" Alias "Alias_M3F20xm_ADCReset@4" (ByVal byIndex As Byte) As Boolean
    Public Declare Function M3F20xm_ADCStandBy Lib "USB2DaqsA.dll" Alias "_M3F20xm_ADCStandBy@4" (ByVal byIndex As Byte) As Boolean

    Public Declare Function M3F20xm_DFUPinGet Lib "USB2DaqsA.dll" Alias "M3F20xm_DFUPinGet@0" (ByVal byIndex As Byte, ByRef pbylevel As Byte) As Boolean
    Public Declare Function M3F20xm_DFUPinSet Lib "USB2DaqsA.dll" Alias "M3F20xm_DFUPinSet@0" (ByVal byIndex As Byte, ByVal byLevel As Byte) As Boolean
#End If









End Module
